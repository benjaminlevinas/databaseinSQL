CREATE DATABASE  IF NOT EXISTS `booking` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `booking`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: booking
-- ------------------------------------------------------
-- Server version	8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `additionalcontactdetails`
--

DROP TABLE IF EXISTS `additionalcontactdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `additionalcontactdetails` (
  `AdditionalContactID` int NOT NULL,
  `PhoneNumber` varchar(20) NOT NULL,
  `SecondaryPhoneNumber` varchar(20) DEFAULT NULL,
  `SecondaryEmailAddress` varchar(50) DEFAULT NULL,
  `InstagramHandle` varchar(50) DEFAULT NULL,
  `FacebookHandle` varchar(50) DEFAULT NULL,
  `SkypeID` varchar(50) DEFAULT NULL,
  `PreferredContactPeriod` varchar(50) DEFAULT NULL,
  `PreferredContactType` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`AdditionalContactID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `address` (
  `AddressID` int NOT NULL,
  `StreetName` varchar(50) NOT NULL,
  `StreetNumber` int NOT NULL,
  `ApartmentNumber` int DEFAULT NULL,
  `City` varchar(50) NOT NULL,
  `State` varchar(50) NOT NULL,
  `ZipCode` int NOT NULL,
  PRIMARY KEY (`AddressID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `amenities`
--

DROP TABLE IF EXISTS `amenities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `amenities` (
  `AmenityID` int NOT NULL,
  `Amenity` varchar(50) NOT NULL,
  PRIMARY KEY (`AmenityID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `amenityjointable`
--

DROP TABLE IF EXISTS `amenityjointable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `amenityjointable` (
  `AmenityJoinTableID` int NOT NULL,
  `ListingID` int NOT NULL,
  `AmenityID` int NOT NULL,
  PRIMARY KEY (`AmenityJoinTableID`),
  KEY `FK_1` (`ListingID`),
  KEY `FK_2` (`AmenityID`),
  CONSTRAINT `FK_1` FOREIGN KEY (`ListingID`) REFERENCES `listing` (`ListingID`),
  CONSTRAINT `FK_2` FOREIGN KEY (`AmenityID`) REFERENCES `amenities` (`AmenityID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `discount`
--

DROP TABLE IF EXISTS `discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount` (
  `DiscountID` int NOT NULL,
  `DiscountPercentage` int NOT NULL,
  `DiscountStartDate` date NOT NULL,
  `DiscountEndDate` date NOT NULL,
  PRIMARY KEY (`DiscountID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feejointable`
--

DROP TABLE IF EXISTS `feejointable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feejointable` (
  `FeeJoinTableID` int NOT NULL,
  `ListingID` int NOT NULL,
  `FeeID` int NOT NULL,
  `DiscountID` int DEFAULT NULL,
  PRIMARY KEY (`FeeJoinTableID`),
  KEY `FK_6` (`ListingID`),
  KEY `FK_4` (`FeeID`),
  KEY `FK_5` (`DiscountID`),
  CONSTRAINT `FK_4` FOREIGN KEY (`FeeID`) REFERENCES `fees` (`FeeID`),
  CONSTRAINT `FK_5` FOREIGN KEY (`DiscountID`) REFERENCES `discount` (`DiscountID`),
  CONSTRAINT `FK_6` FOREIGN KEY (`ListingID`) REFERENCES `listing` (`ListingID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fees`
--

DROP TABLE IF EXISTS `fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fees` (
  `FeeID` int NOT NULL,
  `FeeType` varchar(50) NOT NULL,
  `FeeAmount` int DEFAULT NULL,
  PRIMARY KEY (`FeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `guest`
--

DROP TABLE IF EXISTS `guest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guest` (
  `GuestID` int NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `EmailAddress` varchar(50) NOT NULL,
  `IdentificationID` int NOT NULL,
  `AdditionalContactID` int NOT NULL,
  `LoginID` int NOT NULL,
  PRIMARY KEY (`GuestID`),
  KEY `FK_Guest_IdentificationID` (`IdentificationID`),
  KEY `FK_Guest_AdditionalContactID` (`AdditionalContactID`),
  KEY `FK_Guest_LoginID` (`LoginID`),
  CONSTRAINT `FK_Guest_AdditionalContactID` FOREIGN KEY (`AdditionalContactID`) REFERENCES `additionalcontactdetails` (`AdditionalContactID`),
  CONSTRAINT `FK_Guest_IdentificationID` FOREIGN KEY (`IdentificationID`) REFERENCES `verifiedid` (`IdentificationID`),
  CONSTRAINT `FK_Guest_LoginID` FOREIGN KEY (`LoginID`) REFERENCES `login` (`LoginID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `host`
--

DROP TABLE IF EXISTS `host`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host` (
  `HostID` int NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `EmailAddress` varchar(50) NOT NULL,
  `IdentificationID` int NOT NULL,
  `ListingID` int NOT NULL,
  `AdditionalContactID` int NOT NULL,
  `LoginID` int NOT NULL,
  PRIMARY KEY (`HostID`),
  KEY `FK_ListingID` (`ListingID`),
  KEY `FK_AdditionalContactID` (`AdditionalContactID`),
  KEY `FK_LoginID` (`LoginID`),
  KEY `FK_IdentificationID` (`IdentificationID`),
  CONSTRAINT `FK_AdditionalContactID` FOREIGN KEY (`AdditionalContactID`) REFERENCES `additionalcontactdetails` (`AdditionalContactID`),
  CONSTRAINT `FK_IdentificationID` FOREIGN KEY (`IdentificationID`) REFERENCES `verifiedid` (`IdentificationID`),
  CONSTRAINT `FK_ListingID` FOREIGN KEY (`ListingID`) REFERENCES `listing` (`ListingID`),
  CONSTRAINT `FK_LoginID` FOREIGN KEY (`LoginID`) REFERENCES `login` (`LoginID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `houserules`
--

DROP TABLE IF EXISTS `houserules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `houserules` (
  `HouseRulesID` int NOT NULL,
  `Rule` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `houserulesjointable`
--

DROP TABLE IF EXISTS `houserulesjointable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `houserulesjointable` (
  `ListingID` int NOT NULL,
  `HouseRulesID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `listing`
--

DROP TABLE IF EXISTS `listing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `listing` (
  `ListingID` int NOT NULL,
  `ListingDescription` varchar(500) DEFAULT NULL,
  `AddressID` int NOT NULL,
  `ListingTypeID` int NOT NULL,
  PRIMARY KEY (`ListingID`),
  KEY `FK_8` (`AddressID`),
  KEY `FK_9` (`ListingTypeID`),
  CONSTRAINT `FK_8` FOREIGN KEY (`AddressID`) REFERENCES `address` (`AddressID`),
  CONSTRAINT `FK_9` FOREIGN KEY (`ListingTypeID`) REFERENCES `listingtype` (`ListingTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `listingtype`
--

DROP TABLE IF EXISTS `listingtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `listingtype` (
  `ListingTypeID` int NOT NULL,
  `ListingType` varchar(50) NOT NULL,
  PRIMARY KEY (`ListingTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `LoginID` int NOT NULL,
  `Loginusername` varchar(50) NOT NULL,
  `Loginpassword` varchar(50) NOT NULL,
  `2FAEmail` varchar(50) DEFAULT NULL,
  `2FAPhoneNumber` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`LoginID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `PaymentID` int NOT NULL,
  `GuestID` int NOT NULL,
  `ReservationID` int NOT NULL,
  `PaymentMethodID` int NOT NULL,
  `FeeID` int NOT NULL,
  `DiscountID` int DEFAULT NULL,
  `PaymentAmount` int NOT NULL,
  PRIMARY KEY (`PaymentID`),
  KEY `FK_Guest_Payment` (`GuestID`),
  KEY `FK_Reservation_Payment` (`ReservationID`),
  KEY `FK_PaymentMethod_Payment` (`PaymentMethodID`),
  KEY `FK_Fee_Payment` (`FeeID`),
  KEY `FK_Discount_Payment` (`DiscountID`),
  CONSTRAINT `FK_Discount_Payment` FOREIGN KEY (`DiscountID`) REFERENCES `discount` (`DiscountID`),
  CONSTRAINT `FK_Fee_Payment` FOREIGN KEY (`FeeID`) REFERENCES `fees` (`FeeID`),
  CONSTRAINT `FK_Guest_Payment` FOREIGN KEY (`GuestID`) REFERENCES `guest` (`GuestID`),
  CONSTRAINT `FK_PaymentMethod_Payment` FOREIGN KEY (`PaymentMethodID`) REFERENCES `paymentmethod` (`PaymentMethodID`),
  CONSTRAINT `FK_Reservation_Payment` FOREIGN KEY (`ReservationID`) REFERENCES `reservation` (`ReservationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paymentmethod`
--

DROP TABLE IF EXISTS `paymentmethod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paymentmethod` (
  `PaymentMethodID` int NOT NULL,
  `PaymentType` varchar(50) NOT NULL,
  PRIMARY KEY (`PaymentMethodID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `ReservationID` int NOT NULL,
  `HostID` int NOT NULL,
  `ListingID` int NOT NULL,
  `GuestID` int NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  PRIMARY KEY (`ReservationID`),
  KEY `FK_Host_Reservation` (`HostID`),
  KEY `FK_Listing_Reservation` (`ListingID`),
  KEY `FK_Guest_Reservation` (`GuestID`),
  CONSTRAINT `FK_Guest_Reservation` FOREIGN KEY (`GuestID`) REFERENCES `guest` (`GuestID`),
  CONSTRAINT `FK_Host_Reservation` FOREIGN KEY (`HostID`) REFERENCES `host` (`HostID`),
  CONSTRAINT `FK_Listing_Reservation` FOREIGN KEY (`ListingID`) REFERENCES `listing` (`ListingID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `ReviewID` int NOT NULL,
  `ReservationID` int NOT NULL,
  `ListingID` int NOT NULL,
  `GuestID` int NOT NULL,
  `Comment` varchar(500) NOT NULL,
  PRIMARY KEY (`ReviewID`),
  KEY `FK_Reservation_Reviews` (`ReservationID`),
  KEY `FK_Listing_Reviews` (`ListingID`),
  KEY `FK_Guest_Reviews` (`GuestID`),
  CONSTRAINT `FK_Guest_Reviews` FOREIGN KEY (`GuestID`) REFERENCES `guest` (`GuestID`),
  CONSTRAINT `FK_Listing_Reviews` FOREIGN KEY (`ListingID`) REFERENCES `listing` (`ListingID`),
  CONSTRAINT `FK_Reservation_Reviews` FOREIGN KEY (`ReservationID`) REFERENCES `reservation` (`ReservationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `supportrep`
--

DROP TABLE IF EXISTS `supportrep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supportrep` (
  `SupportRepID` int NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `CompanyEmailAddress` varchar(50) NOT NULL,
  PRIMARY KEY (`SupportRepID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `supportrepjointable`
--

DROP TABLE IF EXISTS `supportrepjointable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supportrepjointable` (
  `SupportRepJoinTableID` int NOT NULL,
  `SupportRepID` int NOT NULL,
  `SupporrTicketID` int NOT NULL,
  PRIMARY KEY (`SupportRepJoinTableID`),
  KEY `FK_SupportRepJoinTable_SupportRep` (`SupportRepID`),
  KEY `FK_SupportRepJoinTable_SupportTicket` (`SupporrTicketID`),
  CONSTRAINT `FK_SupportRepJoinTable_SupportRep` FOREIGN KEY (`SupportRepID`) REFERENCES `supportrep` (`SupportRepID`),
  CONSTRAINT `FK_SupportRepJoinTable_SupportTicket` FOREIGN KEY (`SupporrTicketID`) REFERENCES `supportticket` (`SupportTicketID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `supportticket`
--

DROP TABLE IF EXISTS `supportticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supportticket` (
  `SupportTicketID` int NOT NULL,
  `ReservationID` int NOT NULL,
  `HostID` int NOT NULL,
  `GuestID` int NOT NULL,
  `SupportIssue` varchar(500) NOT NULL,
  `TicketStatus` varchar(50) NOT NULL,
  PRIMARY KEY (`SupportTicketID`),
  KEY `FK_10` (`ReservationID`),
  KEY `FK_11` (`HostID`),
  KEY `FK_12` (`GuestID`),
  CONSTRAINT `FK_10` FOREIGN KEY (`ReservationID`) REFERENCES `reservation` (`ReservationID`),
  CONSTRAINT `FK_11` FOREIGN KEY (`HostID`) REFERENCES `host` (`HostID`),
  CONSTRAINT `FK_12` FOREIGN KEY (`GuestID`) REFERENCES `guest` (`GuestID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `verifiedid`
--

DROP TABLE IF EXISTS `verifiedid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verifiedid` (
  `IdentificationID` int NOT NULL,
  `IdentificationDocument` varchar(50) NOT NULL,
  `IDNumber` varchar(20) NOT NULL,
  PRIMARY KEY (`IdentificationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'booking'
--

--
-- Dumping routines for database 'booking'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-18 14:56:27
